# abctechnologies code
"# assignment1" 
